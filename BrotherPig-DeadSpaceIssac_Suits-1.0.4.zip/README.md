# BrothePigs Suits

Adds Many Cool Suits. Requires [MoreSuits](https://thunderstore.io/c/lethal-company/p/x753/More_Suits/) to appear correctly.


## Changelog:

### v1.0.0

- Release