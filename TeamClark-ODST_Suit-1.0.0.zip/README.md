# ODST Suit

Adds an ODST suit from Halo to the game. Requires [MoreSuits](https://thunderstore.io/c/lethal-company/p/x753/More_Suits/) to appear correctly.

![](https://i.imgur.com/gVtU7Lg.png)
![](https://i.imgur.com/MYOJMfm.png)

## Changelog:

### v1.0.0

- Release